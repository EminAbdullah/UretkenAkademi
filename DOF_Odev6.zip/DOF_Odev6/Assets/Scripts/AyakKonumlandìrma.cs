using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AyakKonumlandırma : MonoBehaviour
{
    [SerializeField]
    float isinMesafesiNormal= .1f, isinOffset = .3f;

    [SerializeField]
    Transform sagAyakTarget,sagAyakHint ,solAyakTarget, solAyakHint;

    [SerializeField]
    LayerMask yurunebilirYerler;

    Vector3 sagAyakTargetPos,sagAyakTargetNormal, sagAyakTargetRot,sagAyakHintPos;
    Vector3 solAyakTargetPos, solAyakTargetNormal, solAyakTargetRot, solAyakHintPos;

    Animator anim;

    bool sagAyakIK=false, solAyakIK = false;
    float IsınToplamMesafe
    {
        get
        {
            return isinMesafesiNormal + isinOffset;
        }
    }

    private void Start()
    {
        anim = GetComponent<Animator>();
    }
    private void LateUpdate()
    {  
        if (sagAyakIK)
        {
            sagAyakTarget.position = sagAyakTargetPos;
            sagAyakTarget.rotation = Quaternion.LookRotation(sagAyakTargetRot, sagAyakTargetNormal);
            sagAyakHint.position = sagAyakHintPos;
        }

        if (solAyakIK)
        {
            solAyakTarget.position = solAyakTargetPos;
            solAyakTarget.rotation = Quaternion.LookRotation(solAyakTargetRot, solAyakTargetNormal);
            solAyakHint.position = solAyakHintPos;
        }
        
        /*
        Ray ray = new Ray(sagAyakTarget.position + Vector3.up * isinOffset, Vector3.down);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, IsınToplamMesafe, yurunebilirYerler))
        {
            Debug.DrawRay(ray.origin, IsınToplamMesafe * ray.direction, Color.red);
            sagAyakTarget.position = hit.point;
            sagAyakTarget.up = hit.normal;
         
        }

        ray = new Ray(solAyakTarget.position + Vector3.up * isinOffset, Vector3.down);

        if (Physics.Raycast(ray, out hit, IsınToplamMesafe, yurunebilirYerler))
        {
            Debug.DrawRay(ray.origin, IsınToplamMesafe * ray.direction, Color.red);
            solAyakTarget.position = hit.point;
            solAyakTarget.up = hit.normal;
           
        }

        */
    }
    
    private void OnAnimatorIK(int layerIndex)
    {
        Vector3 sagAyakPos = anim.GetIKPosition(AvatarIKGoal.RightFoot);
        Quaternion sagAyakRot=anim.GetIKRotation(AvatarIKGoal.RightFoot);

        Ray ray = new Ray(sagAyakPos + Vector3.up * isinOffset, Vector3.down);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, IsınToplamMesafe, yurunebilirYerler))
        {
            Debug.DrawRay(ray.origin, IsınToplamMesafe * ray.direction, Color.red);
            sagAyakTargetPos = hit.point;
            sagAyakTargetNormal = hit.normal;
            sagAyakTargetRot = Vector3.ProjectOnPlane(sagAyakRot * Vector3.forward, hit.normal).normalized;
            sagAyakHintPos = anim.GetIKHintPosition(AvatarIKHint.RightKnee);
            sagAyakIK = true;
        }
        else
        {
            sagAyakIK = false;
        }


        Vector3 solAyakPos = anim.GetIKPosition(AvatarIKGoal.LeftFoot);
        Quaternion solAyakRot = anim.GetIKRotation(AvatarIKGoal.LeftFoot);

        ray = new Ray(solAyakPos + Vector3.up * isinOffset, Vector3.down);

        if (Physics.Raycast(ray, out hit, IsınToplamMesafe, yurunebilirYerler))
        {
            Debug.DrawRay(ray.origin, IsınToplamMesafe * ray.direction, Color.red);
            solAyakTargetPos = hit.point;
            solAyakTargetNormal = hit.normal;
            solAyakTargetRot = Vector3.ProjectOnPlane(solAyakRot * Vector3.forward, hit.normal).normalized;
            solAyakHintPos = anim.GetIKHintPosition(AvatarIKHint.LeftKnee);
            solAyakIK = true;
        }
        else
        {
            solAyakIK = false;
        }
    }

    

}
