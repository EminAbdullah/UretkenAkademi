using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
public class LoadPrefs : MonoBehaviour
{
    [Header("Genel Ayarlar")]
    [SerializeField] private bool canUse=false;
    [SerializeField] private Ayarlar ayarlar;

    [Header("Ses Ayarlar�")]
    [SerializeField] private TMP_Text volumeTextValue =null;
    [SerializeField] private Slider volumeSlider = null;

    [Header("Parlakl�k Ayarlar�")]
    [SerializeField] private Slider brightnessSlider = null;
    [SerializeField] private TMP_Text brightnessTextValue = null;

    [Header("Quality Level Ayarlar�")]
    [SerializeField] private TMP_Dropdown qualityDropdown;

    [Header("FullScreen Settings")]
    [SerializeField] private Toggle fullScreenToggle;

    [Header("Sensitivity Settings")]
    [SerializeField] private TMP_Text controllerSensTextValue = null;
    [SerializeField] private Slider controllerSensSlider = null;

    [Header("invert Y settings")]
    [SerializeField] private Toggle invertYToggle = null;

    private void Awake()
    {
        if (canUse)
        {
            if (PlayerPrefs.HasKey("masterVolume"))
            {

                float localVolume = PlayerPrefs.GetFloat("masterVolume");
                volumeTextValue.text = localVolume.ToString("0.0");
                volumeSlider.value= localVolume;
                AudioListener.volume = localVolume;

            }
            else
            {
                ayarlar.ResetButton("Audio");
            }


            if (PlayerPrefs.HasKey("masterQuality"))
            {

                int localQuality = PlayerPrefs.GetInt("masterQuality");
                qualityDropdown.value = localQuality;
                QualitySettings.SetQualityLevel(localQuality);

            }

            if (PlayerPrefs.HasKey("masterFullScreen"))
            {
                int localFullScreen = PlayerPrefs.GetInt("masterFullScreen");
                if (localFullScreen==1)
                {
                    Screen.fullScreen = true;
                    fullScreenToggle.isOn = true;
                }
                else
                {
                    Screen.fullScreen= false;
                    fullScreenToggle.isOn = false;
                }

            }

            if (PlayerPrefs.HasKey("masterBrightness"))
            {
                float localBrightness = PlayerPrefs.GetFloat("masterBrightness");

                brightnessTextValue.text = localBrightness.ToString("0.0");
                controllerSensSlider.value = localBrightness;   
               
            }

            if (PlayerPrefs.HasKey("masterSen"))
            {
                float localSensitivity = PlayerPrefs.GetFloat("masterSen");

                controllerSensTextValue.text= localSensitivity.ToString("0");
                controllerSensSlider.value= localSensitivity;
                ayarlar.mainControllerSen = Mathf.RoundToInt(localSensitivity);
            }

            if (PlayerPrefs.HasKey("masterInvertY"))
            {
                if (PlayerPrefs.GetInt("masterInvertY")==1)
                {
                    invertYToggle.isOn = true;

                }
                else
                {
                    invertYToggle.isOn= false;
                }

            }


        }


    }
}
