using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.EventSystems;

public class ConnectToServer : MonoBehaviour
{
    public static ConnectToServer instance;

    private void Awake()
    {
        instance = this;
    }


    public TMP_InputField usernameInput;
    public GameObject kullaniciAdiBtn;
    public GameObject menuButtons;

    public static bool hasSetNick=false;
    public GameObject nameInputScreen;

    public GameObject ayarlarPanel;

    public GameObject tekOyunculuPanel;

    public TMP_Text profilText;

    void Start()
    {
        CloseMenus();
        menuButtons.SetActive(true);
        kullaniciAdiBtn.SetActive(true);



        if (PlayerPrefs.HasKey("playerName"))
        {
            if (PlayerPrefs.GetString("playerName")=="")
            {
                profilText.text = "Kullan�c� Ad�";

                usernameInput.text = PlayerPrefs.GetString("playerName");

            }
          
        }
       

        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    private void CloseMenus()
    {
       // loadingScreen.SetActive(false);
        menuButtons.SetActive(false);
        //errorPanel.SetActive(false);     
        nameInputScreen.SetActive(false);   
        kullaniciAdiBtn.SetActive(false);
        ayarlarPanel.SetActive(false);
        tekOyunculuPanel.SetActive(false);

    }



    public void KullaniciAdiOnayla()
    {
        if (!string.IsNullOrEmpty(usernameInput.text))
        {
       

            PlayerPrefs.SetString("playerName", usernameInput.text);
            profilText.text = PlayerPrefs.GetString("playerName");

           

            hasSetNick = true;
        }
        else
        {
            
                PlayerPrefs.SetString("playerName", usernameInput.text);
                profilText.text = "Kullan�c� Ad�";

                hasSetNick = false;
            
          

        }

        CloseMenus();
        kullaniciAdiBtn.SetActive(true);
        menuButtons.SetActive(true);


    }

    public void KullaniciAdi()
    {
        
        kullaniciAdiBtn.SetActive(true);
        menuButtons.SetActive(true);
        nameInputScreen.SetActive(true);
    }

    public void CloseKullaniciAdi()
    {
        CloseMenus();
        kullaniciAdiBtn.SetActive(true);
        menuButtons.SetActive(true);
    }

    public void OpenCokOyunculuPanel()
    {
        SceneManager.LoadScene("Lobby");
    }

    public void OpenAyarlarPanel()
    {
        CloseMenus();
        ayarlarPanel.SetActive(true);

    }


    public void CloseAll()
    {

        CloseMenus();
    }

    public void OpenTekOyunculu()
    {
        if (tekOyunculuPanel.activeSelf==true)
        {
            tekOyunculuPanel.SetActive(false);
        }
        else
        {
            tekOyunculuPanel.SetActive(true);
        }


    }

    public void QuitGame()
    {

        Application.Quit();
    }

}
