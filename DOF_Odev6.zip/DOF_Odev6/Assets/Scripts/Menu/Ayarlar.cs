using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class Ayarlar : MonoBehaviour
{
    [Header("Ses Ayarlar�")]
    [SerializeField] private TMP_Text volumeTextValue=null;
    [SerializeField] private Slider volumeSlider = null;
    [SerializeField] private float defaultVolume = 0.5f;

    [Header("Oynan�� Ayarlar�")]
    [SerializeField] private TMP_Text controllerSensValue = null;
    [SerializeField] private Slider controllerSensSlider = null;
    [SerializeField] private int defaultSens = 4;
    public int mainControllerSen = 4;

    [Header("Toggle Ayarlar�")]
    [SerializeField] private Toggle invertYToggle = null;

    [Header("Grafik Ayarlar�")]
    [SerializeField] private TMP_Text parlaklikTextValue = null;
    [SerializeField] private Slider parlaklikSlider = null;
    [SerializeField] private float defaultParlaklik = 4;

    private int _qualityLevel;
    private bool _isFullScreen;
    private float _parlaklikLevel;

    [Header("Confirmation Ayarlar�")]
    [SerializeField] private GameObject confirmationPrompt = null;

    [Header("��z�n�rl�k dropdown Ayarlar�")]
    public TMP_Dropdown resolutionDropdown;
    private Resolution[] resolutions;

    [Space(10)]
    [SerializeField] private TMP_Dropdown qualityDropdown;
    [SerializeField] private Toggle fullScreenToggle;


    public GameObject volumePanel;
    public GameObject gameplayPanel;
    public GameObject graphicsPanel;
    // Start is called before the first frame update
    void Start()
    {
        CloseMenus();

        resolutions = Screen.resolutions;
        resolutionDropdown.ClearOptions();

        List<string> options = new List<string>();

        int currentResolutionIndex = 0;

        for (int i = 0; i < resolutions.Length; i++)
        {
            string option = resolutions[i].width + " x " + resolutions[i].height;
            options.Add(option);
            if (resolutions[i].width == Screen.width && resolutions[i].height == Screen.height)
            {
                currentResolutionIndex = i;
            }

            resolutionDropdown.AddOptions(options);
            resolutionDropdown.value = currentResolutionIndex;
            resolutionDropdown.RefreshShownValue();
        }

    }


    public void CloseMenus()
    {
        volumePanel.SetActive(false);
        gameplayPanel.SetActive(false);
        graphicsPanel.SetActive(false);
    }

    public void OpenVolumePanel()
    {
        CloseMenus();
        volumePanel.SetActive(true);
    }

    public void SetVolume(float volume)
    {
        AudioListener.volume = volume;
        volumeTextValue.text=volume.ToString("0.0");

    }

    public void ResetButton(string menuType)
    {
        if (menuType =="Audio")
        {
            AudioListener.volume = defaultVolume;
            volumeSlider.value = defaultVolume;
            volumeTextValue.text = defaultVolume.ToString("0.0");
            VolumeApply();

        }
        else if (menuType== "Gameplay")
        {
            controllerSensValue.text = defaultSens.ToString("0");
            controllerSensSlider.value = defaultSens;
            mainControllerSen = defaultSens;
            invertYToggle.isOn = false;
            GameplayApply();
        }
        else if (menuType =="Graphics")
        {

            parlaklikSlider.value = defaultParlaklik;
            parlaklikTextValue.text = defaultParlaklik.ToString("0.0");

            qualityDropdown.value = 1;
            QualitySettings.SetQualityLevel(1);

            fullScreenToggle.isOn = false;
            Screen.fullScreen = false;

            Resolution currentResolution = Screen.currentResolution;
            Screen.SetResolution(currentResolution.width, currentResolution.height, Screen.fullScreen);
            resolutionDropdown.value = resolutions.Length;
            GraphicsApply();
        }


    }

    public void VolumeApply()
    {
        PlayerPrefs.SetFloat("masterVolume", AudioListener.volume);
        StartCoroutine(ConfirmationBox());

    }

    public IEnumerator ConfirmationBox()
    {
        
        confirmationPrompt.SetActive(true);
        yield return new WaitForSeconds(2);
        confirmationPrompt.SetActive(false);
    }

    public void CloseSettings()
    {
        CloseMenus();
    }

    public void SetControllerSens(float sensitivity)
    {
        mainControllerSen = Mathf.RoundToInt(sensitivity);
        controllerSensValue.text = sensitivity.ToString("0");

    }

    public void SetResolution(int resolutionIndex)
    {
        Resolution resolution = resolutions[resolutionIndex];
        Screen.SetResolution(resolution.width,resolution.height, Screen.fullScreen);

    }

    public void GameplayApply()
    {
        if (invertYToggle.isOn)
        {
            PlayerPrefs.SetInt("masterInvertY", 1);//Invert Y
        }
        else
        {
            PlayerPrefs.SetInt("masterInvertY", 0);
        }
        PlayerPrefs.SetFloat("masterSen", mainControllerSen);
        StartCoroutine(ConfirmationBox());
    }

    public void OpenGameplayPanel()
    {
        CloseMenus();
        gameplayPanel.SetActive(true);
    }

    public void OpenGraphicsPanel()
    {
        CloseMenus();
        graphicsPanel.SetActive(true);
    }

    public void SetBrightness(float brightness)
    {
        _parlaklikLevel = brightness;
        parlaklikTextValue.text = brightness.ToString("0.0");
    }


    public void setFullScreen(bool isFullScreen)
    {
        _isFullScreen = isFullScreen;
    }

    public void setQuality(int qualityIndex)
    {
        _qualityLevel = qualityIndex;
    }

    public void GraphicsApply()
    {
        PlayerPrefs.SetFloat("masterBrightness", _parlaklikLevel);

        PlayerPrefs.SetInt("masterQuality", _qualityLevel);
        QualitySettings.SetQualityLevel(_qualityLevel);

        PlayerPrefs.SetInt("masterFullScreen",(_isFullScreen?1:0));
        Screen.fullScreen = _isFullScreen;

        StartCoroutine(ConfirmationBox());
    }
}
