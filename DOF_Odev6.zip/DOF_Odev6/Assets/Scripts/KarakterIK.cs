using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KarakterIK : MonoBehaviour
{
    [SerializeField]
    Transform kafaHedefi, kafaBakis;

    [SerializeField]
    Transform solElHedef;


    [SerializeField]
    float solElMesafe=0.5f;

    float kafaAci = 90f;

    private void LateUpdate()
    {
        float vertical = Input.GetAxis("Mouse Y");
        float horizontal = Input.GetAxis("Mouse X");

        //transform.Rotate(Vector3.up *horizontal);

        kafaAci +=vertical;

        kafaAci = Mathf.Clamp(kafaAci, 0, 180);

        Vector3 kafaPos = new Vector3(0,Mathf.Sin(kafaAci*Mathf.Deg2Rad),Mathf.Cos(kafaAci*Mathf.Deg2Rad));
        kafaHedefi.transform.localPosition = kafaPos;

        Vector3 kafaBakisPos = new Vector3(0, Mathf.Sin((kafaAci-90 )* Mathf.Deg2Rad), Mathf.Cos((kafaAci - 90) * Mathf.Deg2Rad));
        kafaBakis.transform.localPosition = kafaBakisPos  ;


        Vector3 solElPos = kafaHedefi.position -Camera.main.transform.position;
        solElPos.Normalize();

        solElHedef.position = Vector3.Lerp(Camera.main.transform.position, kafaBakis.position, solElMesafe);
        solElHedef.LookAt(kafaBakis.position);

    }
}
