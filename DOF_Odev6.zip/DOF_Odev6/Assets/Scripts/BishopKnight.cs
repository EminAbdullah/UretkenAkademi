using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class BishopKnight : MonoBehaviour
{
    private int HP=100;
    public Animator anim;

    public Slider healthBar;


    private void Update()
    {
        healthBar.value = HP;
    }

    public void TakeDamage(int damageAmount)
    {
        HP -= damageAmount;
        if (HP <=0)
        {
            anim.SetTrigger("die");
            GetComponent<BoxCollider>().enabled = false;
        }
        else
        {
            anim.SetTrigger("damage");
        }

    }
}
