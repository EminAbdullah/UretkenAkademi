using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BolenleriBul : MonoBehaviour
{
   
    void Start()
    {
        bolenleriBulList(20,44);
        print("**************** Yukar� k�s�m liste ile Alttaki k�s�m listesiz �ekilde *******************");
        bolenleriBul(20, 44);
    }


    private void bolenleriBul(int ilkSayi,int ikinciSayi)
    {
        string a="";
        string b = "";
        string c = "";
        string d = "";
        string e = "";
        
            for (int i = ilkSayi; i <= ikinciSayi; i++)
            {
                a += " ," + i;
                if (i%2==0)
                {
                    b += " ," + i;
                    if (i % 4 == 0)
                    {
                        d += " ," + i;
                    }
                }
                if (i%3==0)
                {
                    c += " ," + i;
                }
                if (i % 5 == 0)
                {
                    e += " ," + i;
                }


            }
            print("T�m Liste: "+a);
            print("�kiye B�l�nenler: "+b);
            print("��e B�l�nenler"+c);
            print("D�rde B�l�nenler" + d);
            print("Be�e B�l�nenler" + e);
        

    }


    private void bolenleriBulList(int ilkSayi, int ikinciSayi)
    {
        string a = "";
        string b = "";
        string c = "";
        string d = "";
        string e = "";

        List<int> bolenler = new List<int>();
        if (ilkSayi<ikinciSayi)
        {
            for (int i = ilkSayi; i <= ikinciSayi; i++)
            {
                bolenler.Add(i);
            }
        }
        else
        {
            for (int i = ikinciSayi; i <= ilkSayi; i++)
            {
                bolenler.Add(i);
            }
        }
      
 
        foreach (var sayi in bolenler)
        {
            a += " ," + sayi;
            if (sayi % 2 == 0)
            {
                b += " ," + sayi;
                if (sayi % 4 == 0)
                {
                    d += " ," + sayi;
                }
            }
            if (sayi % 3 == 0)
            {
                c += " ," + sayi;
            }
            if (sayi % 5 == 0)
            {
                e += " ," + sayi;
            }


        }
        print("T�m Liste: " + a);
        print("�kiye B�l�nenler: " + b);
        print("��e B�l�nenler" + c);
        print("D�rde B�l�nenler" + d);
        print("Be�e B�l�nenler" + e);

    }




}
