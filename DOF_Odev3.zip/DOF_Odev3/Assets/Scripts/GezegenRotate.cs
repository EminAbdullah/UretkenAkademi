using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GezegenRotate : MonoBehaviour
{
    public Vector3 vec;
   

    // Update is called once per frame
    void Update()
    {
      GetComponent<Transform>().Rotate(vec * Time.deltaTime);
    }
}
