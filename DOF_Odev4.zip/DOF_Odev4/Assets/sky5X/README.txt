Original designs by clandestine studio 2008 .
FREE for personal and commercial use.